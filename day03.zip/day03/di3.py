names = [
    ["曹操","56","男","106","IBM", 500 ,"50"],
    ["大乔","19","女","230","微软", 501 ,"60"],
    ["小乔", "19", "女", "210", "Oracle", 600, "60"],
    ["许褚", "45", "男", "230", "Tencent", 700 , "10"]
]
px=(names[0][5]+names[1][5]+names[2][5]+names[3][5])/4
print("平均薪资：",px)
names[0][1]=int(names[0][1])
names[1][1]=int(names[1][1])
names[2][1]=int(names[2][1])
names[3][1]=int(names[3][1])
pn=(names[0][1]+names[1][1]+names[2][1]+names[3][1])/4
print("平均年龄：",pn)
names.append(["刘备","45","男","220","alibaba",500,"30"])
n=names[0].count("男")+names[1].count("男")+names[2].count("男")+names[3].count("男")+names[4].count("男")
m=names[0].count("女")+names[1].count("女")+names[2].count("女")+names[3].count("女")+names[4].count("女")
print("男的人数：",n,"女的人数：",m)
li=[]
for i in range(0,5):
    num=names[i][6]
    li.append(num)
li0=list(set(li))
for a in li0:
    print(a,"部门有：",li.count(a))