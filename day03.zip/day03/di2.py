z = 0
h = 0
p = 0
for i in range(10):
    num = input("请输入：")
    num = int(num)
    t=[num]
    z = t[0]
    for a in t:
        if a < z:
            z = a
    h=h+num
    p=h/10
print("最大值：", z,"  和为：",h,"  平均值为；",p)