s=0
for i in range(10):
    num=input("请输入：")
    num=int(num)
    s=s+num
print(s)