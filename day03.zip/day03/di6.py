import math
a=0
x=0
for i in range(20):
    a=a+1
    c=math.factorial(a)
    x=x+c
print(x)