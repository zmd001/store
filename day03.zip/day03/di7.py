# 有以下一个列表，求其中是5的倍数的和
a = [1,5,21,30,15,9,30,24]
b=0
for i in a:
    a.count(i)
    if i%5==0:
        b=b+i
print(b)