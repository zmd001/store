List = [1,4,7,5,8,2,1,3,4,5,9,7,6,1,10]
c= set(List)
for i in c:
    a=List.count(i)
    print(i,"数量:",a)