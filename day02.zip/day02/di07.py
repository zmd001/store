h=20
s=0
d=0
while True:
    d=d+1
    s=s+3
    if s>=h:
        print(d)
        break
    else:
        s=s-2