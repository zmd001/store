a=56
b=78
a = a + b
b = a - b
a = a - b
print(a,b)

