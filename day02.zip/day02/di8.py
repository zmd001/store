# char     是
# Oax_li   是
# fLul     是
# BYTE     是
# Cy%ty    否
# $123     否
# 3_3      否
# T_T      是