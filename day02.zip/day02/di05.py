num = input("层数：")
num = int(num)
i = 1
while i <= num:
    j = 1
    n = 1
    while n <= num - i :
        print(" ",end="")
        n = n + 1
    while j <= i:
        print(" *",end="")
        j = j + 1
    print()
    i = i + 1