import time
counter = 0
while True:
    if counter >= 3:
        print("锁定三秒")
        a = 1
        while a <= 3:
            time.sleep(1)
            a = a + 1
    counter = counter + 1
    n = input("请输入3位密码：")
    n = int(n)
    if n == 123:
        print("成功")
        break
    else:
        print("错误请重新输入")