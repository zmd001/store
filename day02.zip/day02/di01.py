import random
num = random.randint(50,150)
print(num)