a = input("请输入边：")
b = input("请输入边：")
c = input("请输入边：")
a = int(a)
b = int(b)
c = int(c)
if a + b > c and b + c > a and a + c > b and a > 0 and b > 0 and c > 0:
    if a == b and a == c and c == b:
        print("等边三角形")
    elif a == b or a == c or c == b:
        print("等腰三角形")
    else:
        print("普通三角形")