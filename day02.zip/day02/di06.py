num = input("输入：")
num =int(num)
n = 1
while n <= num:
    m = 19
    while m <= num+1-n:
        print(m,"x",n,"=",(m*n),"\t",end="")
        m = m + 1
    print()
    n = n +1
