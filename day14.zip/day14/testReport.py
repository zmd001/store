from day14.TestCalc import TestCalc
import unittest
from HTMLTestRunner import HTMLTestRunner
suite = unittest.TestSuite()

suite.addTest(TestCalc("testAdd"))
suite.addTest(TestCalc("testMenus"))
suite.addTest(TestCalc("testMulti"))
suite.addTest(TestCalc("testDevision"))

f = open("计算器测试报告.html","w+",encoding="utf-8")
runner = HTMLTestRunner.HTMLTestRunner(
    stream=f,
    title="计算器加法测试报告",
    verbosity=1
)

runner.run(suite)