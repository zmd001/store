from day14.Calc import Calc
import unittest
class TestCalc(unittest.TestCase):

    def testAdd(self):
        a = 5
        b = 6
        s = 11
        c = Calc()
        sum = c.add(a,b)
        self.assertEqual(s,sum)

    def testMenus(self):
        a = 7
        b = 6
        s = 1
        c = Calc()
        sum = c.menus(a,b)
        self.assertEqual(s,sum)

    def testMulti(self):
        a = 2
        b = 3
        s = 6
        c = Calc()
        sum = c.multi(a,b)
        self.assertEqual(s,sum)

    def testDevision(self):
        a = 8
        b = 4
        s = 2
        c = Calc()
        sum = c.devision(a,b)
        self.assertEqual(s,sum)
