import requests


response = requests.post(url="http://www.jasonisoft.cn:8080/HKR/CourseServlet?method=findAllTeachenr")
response.encoding = "utf-8"
users = response.json()
f= open("评价数据.txt","w+",encoding="utf-8")
for user in users:
    f.write(str(dict(user).values()))
























