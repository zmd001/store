import requests
import pymysql

# 请求url地址并得到数据
response = requests.post(url="http://www.jasonisoft.cn:8080/HKR/UserServlet?method=findAllStudent")
response.encoding = "utf-8"


# 将json数据提取为字典
data = response.json()

lis13 = [] # [["沙河",52,sniper,Python自动],[],[]     ]
lis14 = []
for user in data:
    vas = dict(user).values()
    if len(vas) == 13:
        u = list(user.keys())
        data = list(vas)        # 数据处理：将'' 转换换成"空数据"
        for i in range(len(data)):

            data[i] = data[i] if data[i] != "" else "空数据"
        u.extend(data)
        lis13.append(u)
    else:
        lis14.append(vas)

#  使用pymysql 插入数据
sql14 = "insert into person(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) " \
      "values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
sql13 =  "insert into person(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) " \
      "values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
con = pymysql.connect(host="localhost",user="root",password="root",database="bank")

cursor = con.cursor()

cursor.executemany(sql13,lis13)
# cursor.executemany(sql14,lis14)

con.commit()

cursor.close()

con.close()


'''
    address
    age  carte classname email   graduation id  loginname phoneNumber  picturePath    registerDate  sex  uid
    username

'''