from day12.ti3 import find
import xlrd
import xlwt
# wb = xlrd.open_workbook("G:\Py\pythonProject\day12\衣服销售数据.xls")
# sheet = wb.sheet_by_name("衣服销售数据")
# rows = sheet.nrows
# for i in range(rows):
#     if i > 0:
#         sql = "insert into 衣服销售管理 values(%s,%s,%s,%s,%s)"
#         param = [sheet.row_values(i)[0],sheet.row_values(i)[1],sheet.row_values(i)[2],sheet.row_values(i)[3],sheet.row_values(i)[4]]
#         update(sql, param)
# sql = "select * from 衣服销售管理"
# param = []
# data = find(sql,param)
# print(data)
wb = xlwt.Workbook("销售.xls")
st = wb.add_sheet("用户管理")
sql = "select * from 衣服销售管理"
param = []
data = find(sql,param)
a = 1
for i in data:
    b = 0
    for j in i:
        st.write(a,b,j)
        b = b+1
    a= a + 1
st.write(0,0,"日期")
st.write(0,1,"服装名称")
st.write(0,2,"价格/件")
st.write(0,3,"库存数量")
st.write(0,4,"销售量/每日")
f= open("销售.xls","w+")
wb.save("销售.xls")



































