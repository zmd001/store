import pymysql
import xlrd
import xlwt
host="localhost"
user="root"
password="123456"
database="衣服销售管理"
def update(sql,param):
    con = pymysql.connect(host=host,user=user,password=password,database=database)
    cursor = con.cursor()
    cursor.execute(sql,param)
    con.commit()
    cursor.close()
    con.close()
def find(sql,param,mode="all",size=1):
    con = pymysql.connect(host=host, user=user, password=password, database=database)
    cursor = con.cursor()
    cursor.execute(sql, param)
    con.commit()
    if mode == "all":
        return cursor.fetchall()
    elif mode == "one":
        return cursor.fetchone()
    elif mode == "many":
        return cursor.fetchmany(size)
    cursor.close()
    con.close()
# def read(exl,param):
#     wb = xlrd.open_workbook("G:\Py\pythonProject\day12\衣服销售数据.xls")
#     sheet = wb.sheet_by_name("衣服销售数据")
#     rows = sheet.nrows
#     cols = sheet.ncols


























































































