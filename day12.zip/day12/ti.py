import xlrd
import xlwt

wb = xlrd.open_workbook("G:\Py\pythonProject\day12\衣服销售数据.xls")
sheet = wb.sheet_by_name("衣服销售数据")
rows = sheet.nrows
cols = sheet.ncols
num = 0
num2 = 0
num3 = 0
num4 = 0
num5 = 0
num6 = 0
num7 = 0
for k in range(rows):
    if k > 0:
        c = sheet.row_values(k)[2] * sheet.row_values(k)[4]
        num = num + c
print(round(num, 1))
num1 = 0
for i in range(rows):
    if i > 0:
        a = sheet.row_values(i)[4]
        num1 = num1 + a
print(round(num1/30,0))
for l in range(rows):
    if l >0:
        if sheet.row_values(l)[1] == "羽绒服":
            a = sheet.row_values(l)[4]/500
            num2 = num2 + a
        if sheet.row_values(l)[1] == "牛仔裤":
            a = sheet.row_values(l)[4]/600
            num3 = num3 + a
        if sheet.row_values(l)[1] == "风衣":
            a = sheet.row_values(l)[4]/335
            num4 = num4 + a
        if sheet.row_values(l)[1] == "皮草":
            a = sheet.row_values(l)[4]/855
            num5 = num5 + a
        if sheet.row_values(l)[1] == "T血":
            a = sheet.row_values(l)[4]/632
            num6 = num6 + a
        if sheet.row_values(l)[1] == "衬衫":
            a = sheet.row_values(l)[4]/562
            num7 = num7 + a
v = "%.1f%%" % (num2 * 100)
z = "%.1f%%" % (num3 * 100)
d = "%.1f%%" % (num4 * 100)
e = "%.1f%%" % (num5 * 100)
f = "%.1f%%" % (num6 * 100)
g = "%.1f%%" % (num7 * 100)
print(v,z,d,e,f,g)
a=0
wb = xlwt.Workbook("销售数据.xls")
st = wb.add_sheet("销售数据")
for i in range(rows):
    b=0
    all = sheet.row_values(i)
    for c in all:
        st.write(a,b,c)
        b=b+1
    a=a+1
st.write(32,0,"总销售额：" +str(round(num, 1)))
st.write(32,3,"平均日销售量："+str(round(num1/30,0)))
st.write(32,4,"羽绒服本月销售占比:"+str(v))
st.write(33,4,"牛仔裤本月销售占比:"+str(z))
st.write(34,4,"风衣本月销售占比:"+str(d))
st.write(35,4,"皮草本月销售占比:"+str(e))
st.write(36,4,"T血本月销售占比:"+str(f))
st.write(37,4,"衬衫本月销售占比:"+str(g))
f = open("销售数据.xls","w+")
wb.save("销售数据.xls")

































































































