import random
# 银行的名称

bank_name = "北京市工商银行昌平支行"

# 银行的库
users = {

}
'''
{"张三":
    {account:"12345",
    "国家":"中国"}
}

'''
# 欢迎界面
welcome  = '''
*********************************
*    欢迎来到中国工商银行管理系统 *
*********************************
*    1.开户                      *
*    2.存钱                      *
*    3.取钱                      *
*    4.转账                      *
*    5.查询                      *
*    6.bye！                     *
*********************************
'''
# 专门来获取8位随机账号
def getRandom():
    li = [1,2,3,4,5,6,7,8,9,0]
    # 循环8次
    string = ""
    for i in range(8): # 循环8次获取随机字符
        ch = li[random.randint(0,9)]
        string = string + str(ch)
    return string

# 银行的核心开户方法
def bank_addUser(account,username,password,money,country,province,street,door):
    # 先判断银行库是否已满 ： 100个最大
    if len(users) >= 100:
        return 3
    # 判断是否已经存在
    elif username in users: # 这种方式只判断是否在字典的键里存在
        return 2
    # 可以正常开户：将个人数据存到用户库里
    else:
        users[username] = {
            "account":account,
            "password":password,
            "money":money,
            "country":country,
            "province":province,
            "street":street,
            "door":door,
            "bank_name":bank_name
        }
        return 1





# 普通的开户方法
def addUser():
    # 完成具体的开户输入
    # 姓名(str)、密码(int:6位数字)、地址、存款余额(int)、国家(str)、省份(str)、街道(str)、门牌号(str)
    username = input("请输入姓名：")
    password = input("请输入初始取款密码：")
    money =  int(input("请输入您的初始金额：")) # 金额是整数形式
    print("接下来输入地址信息：")
    country =  input("请输入您所在国家：")
    province = input("亲输入您所在省份：")
    street = input("请输入您所在的街道：")
    door = input("请输入您地址的门牌号：")
    account =  getRandom() # 获取随机账号

    # 将数据传给银行
    status = bank_addUser(account,username,password,money,country,province,street,door)
    if status == 3:
        print("对不起，银行用户已满！请携带证件到其他银行办理！")
    elif status == 2:
        print("对不起，您的个人信息已存在！请勿重复开户！")
    elif status == 1:
        print("恭喜，开户成功！以下是您的个人开户信息：")
        print("-------------------------------------")
        print("您的账号为:",users[username]["account"])
        print("您的密码为:", users[username]["password"])
        print("您的余额为:", users[username]["money"])
        print("您的用户名为:", username)
        print("您所在国家为:", users[username]["country"])
        print("您所在省份为:", users[username]["province"])
        print("您所在街道为:", users[username]["street"])
        print("您所在门牌号为:", users[username]["door"])
        print("开户行名为:", users[username]["bank_name"])
def bank_withdraw(username,password,money):
    a = users.values()     # 把值赋给a
    if username in users:  # 判断用户里面有没有用户名
            if password in users[username]["password"]:
                if (money < users[username]["money"]) or (money == users[username]["money"]):
                    users[username]["money"]=users[username]["money"]-money
                    return 0
                else:
                    return 3
            else:
                return 2
    else:
        return 1

def withdraw():
    username = input("请输入姓名：")
    password = input("请输入取款密码：")
    money = int(input("请输入您要取的金额："))
    returnvalue= bank_withdraw(username,password,money)
    if returnvalue == 1:
        print("用户不存在")
    elif returnvalue == 2:
        print("密码不正确")
    elif returnvalue == 3:
        print("账户余额不足")
    elif returnvalue == 0:
        print("以取出：",money,"元","余额还剩：",users[username]["money"])

while True:
    print(welcome) # 打印欢迎信息
    chose = input("请输入您的业务编号：")
    if chose == "1":
        addUser()
    elif chose == "2":
        print("存钱！")
    elif chose == "3":
        print("请取钱！")
        withdraw()
        print(users)
    elif chose == "4":
        print("转账！")
    elif chose == "5":
        print("查询个人信息！")
    elif chose  == "6":
        print("退出成功！欢迎下次光临！")
        break
    else:
        print("输入非法！请重新输入！")


f = open("names.txt","w+",encoding="utf-8")
for key in users.keys():
    string = ""
    string = string + key # 先拼接姓名
    string = string + "," +  users[key]["account"]
    string = string + "," + str(users[key]["password"])
    string =  string + "," + str(users[key]["money"])
    string = string + "," + users[key]["country"]
    string = string + "," + users[key]["province"]
    string = string + "," + users[key]["street"]
    string = string + "," + users[key]["door"]
    string = string + "," + users[key]["bank_name"]
    print(string)
    # 写入
    f.write(string + "\n")
f.close()
