citys = {
    "010":"北京",
    "020":"上海",
    "030":"广州",
    "040":"深圳",
}
name = citys["010"]
citys["010"] = "安徽"
citys["050"] = "天津"
print(citys)

keys = citys.keys()
for key in keys:
    print(key , "=" , citys.get(key))