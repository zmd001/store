class Student:
    __name = ("")
    __age = ()
    def setName(self,name):
        if len(name) == 0:
            print("请输入姓名")
        else:
            self.__name=name
    def getName(self):
        return self.__name

    def setAge(self,age):
        if age<0 or age>120:
            print("年龄不符")
        else:
            self.__age=age
    def getAge(self):
        return self.__age

    def introduce(self):
        print("大家好，我叫",self.__name,"今年",self.__age,"岁了！")

    def student1(self,name1):
        if self.__age < name1.getAge():
            print("我比同桌大", name1.getAge() - self.__age, "岁")
        elif self.__age > name1.getAge():
            print("我比同桌小", self.__age - name1.getAge(), "岁")
        else:
            print("我和同桌一样大")
s=Student()
s.setName("小明")
s.setAge(15)


s1=Student()
s1.setName("zz")
s1.setAge(16)

s.student1(s1)

















