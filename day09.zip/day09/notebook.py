class Notebook:
    __screen = 0
    __money = 0
    __cpu = 0
    __internal = 0
    __standby = 0
    def setScreen(self,screen):
        if screen<0 or screen>100:
            print("屏幕大小不符")
        else:
            self.__screen=screen
    def getScreen(self):
        return self.__screen

    def setMoney(self,money):
        if money<0:
            print("价格不符")
        else:
            self.__money=money
    def getMoney(self):
        return self.__money

    def setCpu(self,cpu):
        if cpu>0 :
            self.__cpu=cpu
        else:
            print("cpu不符")
    def getCpu(self):
        return self.__cpu

    def setInternal(self,internal):
        if internal<0:
            print("内存不符")
        else:
            self.__internal=internal
    def getInternal(self):
        return self.__internal

    def setStandby(self,standby):
        if standby<0 or standby>24:
            print("待机时长不符")
        else:
            self.__standby=standby
    def getStandby(self):
        return self.__standby

    def typ(self,amount):
        print("待机时长",self.__standby,"小时","打",amount,"个字")
    def game(self,name):
        print("正在打",name)
    def video(self,name):
        print("正在看",name)
n=Notebook()
n.setScreen(40)
n.setMoney(4000)
n.setCpu(2400)
n.setInternal(1)
n.setStandby(6)

n.typ(50000)
n.game("cf")
n.video("天线宝宝")

print("屏幕大小为:",n.getScreen(),
      "寸;价格为:",n.getMoney(),
      "元;cpu型号为:",n.getCpu(),
      "+;内存为:",n.getInternal(),
      "T;待机时长:",n.getStandby(),"小时")







































































