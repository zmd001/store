# class Car:
#     num = 0
#     color = ""
#     brand = ""
#     def run (self,length):
#         print(self.brand + "品牌车在大马路上跑来跑去，已经跑了",length,"千米")
# c = Car()
# c.num=4
# c.color="红色"
# c.brand="奥迪"
#
# c.run(5)



class Person:
    __username = ""
    __sex = ""
    __age = 0
    def setAge(self,age):
        if age <0 or age >120:
            print("非法年龄")
        else:
            self.__age = age
    def getAge(self):
        return self.__age

    def setName(self,name):
        if len(name) == 0:
            print("输入非法")
        else:
            self.__username = name
    def getName(self):
        return self.__username

    def setSex(self,sex):
        if sex == "男" or sex == "女":
            self.__sex = sex
        else:
            print("输入非法")
    def ageSex(self):
        return self.__sex

    def eat(self,name):
        print(self.__username,self.__sex,self.__age,"岁，喜欢吃",name)
    def playGame(self,name):
        print(self.__username,"正在打",name,"游戏")
p = Person()
p.setAge(15)
p.setName("张三")
p.setSex("男")

p.eat("麻辣烫")
p.playGame("和平精英")


































