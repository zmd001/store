import time
class Air:
    __brand =""
    __money = 0
    def setBrand(self,brand):
        if len(brand)==0:
            print("请设置品牌")
        else:
            self.__brand=brand
    def getBrand(self):
        return self.__brand

    def setMoney(self,money):
        if money<0:
            print("价格不符")
        else:
            self.__money=money
    def getMoney(self):
        return self.__money

    def boot(self):
        print("空调开机了")
    def close(self,num):
        print("空调将在",num,"分钟后自动关机....")
        num=60 * num
        time.sleep(num)
a = Air()
class Test:
    a.setBrand("美的")
    a.setMoney(5000)
    a.boot()
    print("品牌为:",a.getBrand(),"价格为:",a.getMoney(),"元")
    a.close(1)






















































































