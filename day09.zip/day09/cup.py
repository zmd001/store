class Cup:
    __high = 0
    __volume = 0
    __color = ""
    __texture = ""

    def setHigh(self,high):
        if high<0 or high>=20:
            print("高度输入非法")
        else:
            self.__high=high
    def getHigh(self):
        return self.__high

    def setVolume(self,volume):
        if volume<0 or volume>100:
            print("容积输入非法")
        else:
            self.__volume=volume
    def getVolume(self):
        return self.__volume

    def setColor(self,color):
        if len(color) == 0:
            print("请输入颜色")
        else:
            self.__color=color
    def getColor(self):
        return self.__color

    def setTexture(self,tuxture):
        if len(tuxture) == 0:
            print("请输入材质")
        else:
            self.__texture=tuxture
    def getTexture(self):
        return self.__texture

    def deposit(self,name):
        print("高度为",self.__high,"容积为",self.__volume,self.__color,self.__texture,"水杯，存放着"+name)
c = Cup()
c.setHigh(15)
c.setVolume(20)
c.setColor("红色")
c.setTexture("玻璃")

c.deposit("可乐")




















