class Person:
    __name=""
    __sex=""
    __age=()
    __telephone=()
    __brand=()
    __capacity=()
    __screen=()
    __duration=()
    __integral=()
    def setName(self,name):
        if len(name)==0:
            print("名字输入非法")
        else:
            self.__name=name
    def getName(self):
        return self.__name

    def setSex(self,sex):
        if sex !="男" or sex!="女":
            print("性别输入非法")
        else:
            self.__sex=sex
    def getSex(self):
        return self.__sex

    def setAge(self,age):
        if age<0 or age>120:
            print("年龄输入非法")
        else:
            self.__age=age
    def getAge(self):
        return self.__age

    def setTelephone(self,telephone):
        if telephone<0:
            print("剩余话费输入非法")
        else:
            self.__telephone=telephone
    def getTelephone(self):
        return self.__telephone

    def setBrand(self,brand):
        if len(brand) ==0:
            print("手机品牌输入非法")
        else:
            self.__brand=brand
    def getBrand(self):
        return self.__brand

    def setCapacity(self,capacity):
        if capacity<0:
            print("手机电池容量输入非法")
        else:
            self.__brand=capacity
    def getCapacity(self):
        return self.__capacity

    def setScreen(self,screen):
        if screen<0 or screen>10:
            print("手机屏幕大小输入非法")
        else:
            self.__brand=screen
    def getScreen(self):
        return self.__screen

    def setduration(self,duration):
        if duration<0:
            print("手机屏幕大小输入非法")
        else:
            self.__brand=duration
    def getduration(self):
        return self.__duration















































