import pymysql
con = pymysql.connect(host="localhost",user="root",password="123456",database="建设银行")
cursor = con.cursor()
sql = "select * from 用户表"
cursor.execute(sql)
data = cursor.fetchall()
print(data)
cursor.close()
con.close()