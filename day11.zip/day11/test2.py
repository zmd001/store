from day11.chef import Grandson

class Test:
    g = Grandson()
    g.setName("张三")
    g.setAge("12")
    g.chef("蒸饭")
    g.fried("炒菜")



