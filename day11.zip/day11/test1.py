#phone
from day11.phone import Newphone

class Test1:
    n = Newphone("aa")
    n.call()