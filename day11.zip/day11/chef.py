class Chef:
    __name = None
    __age = None

    def setName(self,name):
        self.__name=name
    def getName(self):
        return self.__name

    def setAge(self,age):
        self.__age=age
    def getAge(self):
        return self.__age

    def chef(self,chef):
        print(chef)

class Fried(Chef):
    def fried(self,fried):
        print(self.getName(),self.getAge(),fried)

class Grandson(Fried):
    def grandson(self,fried):
        super().fried(fried)
# g=Grandson()
# g.setName("aa")
# g.setAge("12")
# g.chef("cc")
# g.fried("bb")