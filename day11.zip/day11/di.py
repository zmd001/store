class Olephone:
    __num = None
    __song = None
    __address = None

    def __init__(self, num, song, address):
        self.__num = num
        self.__song = song
        self.__address = address

    def setNum(self, num):
        self.__num = num

    def getNum(self):
        return self.__num

    def setSong(self, song):
        self.__song = song

    def getSong(self):
        return self.__song

    def setAddress(self, address):
        self.__address = address

    def getAddress(self):
        return self.__address

    def call(self, phoneNumber):
        print(phoneNumber, "正在打给：", self.getNum(), "铃声为：", self.getSong(), "归属地为：", self.getAddress())


class Newphone(Olephone):
    __pictue = None

    def __init__(self, num, song, address, picture):
        super().__init__(num, song, address)
        self.__pictue = picture

    def setPictue(self,picture):
        self.__pictue=picture

    def getPicture(self):
        return self.__pictue

    def call(self, phoneNumber):
        super().call(phoneNumber)
        print("头像为：", self.getPicture())

n=Newphone("123","aa","aa","aa")
n.call("1333")