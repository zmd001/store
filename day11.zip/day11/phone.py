class Oldphone:
    __brand = None
    def __init__(self,brand):
        self.__brand=brand

    def setBrand(self,brand):
        self.__brand=brand
    def getBrand(self):
        return self.__brand

    def phoneNum(self,phonenum):
        print("正在给",phonenum,"打电话..")

class Newphone(Oldphone):
    def call(self):
        print("语音报号中。。。。")
        super().phoneNum(phonenum="123")
        print("品牌为:",self.getBrand(),"的手机很好用")






























