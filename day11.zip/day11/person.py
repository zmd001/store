'''
i.人：年龄，性别，姓名。
ii.现在有个工种，工人：年龄，性别，姓名 。行为：干活。请用继承的角度来实现该类。
iii.现在有学生这个工种，学生：年龄，性别，姓名，学号。行为：学习，唱歌。请结合上面的几个题目用继承的角度来实现。
'''
class Person:
    __age =None
    __gender =None
    __name = None
    def __init__(self,age,gender,name):
        self.__age=age
        self.__gender=gender
        self.__name=name
    def setAge(self,age):
        self.__age=age
    def getAge(self):
        return self.__age

    def setGender(self,gender):
        self.__gender=gender
    def getGender(self):
        return self.__gender

    def setName(self,name):
        self.__name=name
    def getName(self):
        return self.__name

class Worker(Person):
    def __init__(self,age,gender,name):
        super().__init__(age,gender,name)
    def worker(self,worker):
        print(self.getAge(),self.getGender(),self.getName(),"在",worker)

class Student(Person):
    __number=None
    def __init__(self,age,gender,name,number):
        super().__init__(age,gender,name)
        self.__number=number
    def setNumber(self,number):
        self.__number=number
    def getNumber(self):
        return self.__number

    def behavior(self,study,sing):
        print(self.getNumber(),self.getAge(),self.getGender(),self.getName(),"在",study,"和",sing)


w=Worker("15","男","张三")
w.worker("般砖")

s=Student("13","女","李四","123")
s.behavior("读书","唱歌")

























