import pymongo
import requests
# response = requests.post(url="http://www.jasonisoft.cn:8080/HKR/UserServlet?method=findAllStudent")
# response.encoding = "utf-8"
# data = response.json()
# li = {}
# for li in data:
#     client = pymongo.MongoClient("mongodb://localhost:27017")
#     lists = client.list_database_names()
#     db = client["student"]
#     #增
#     user = li
#     status = db["student"].insert_one(user)
    #删
    # user = {"age":18}
    # status = db["student"].delete_many(user)
client = pymongo.MongoClient("mongodb://localhost:27017")
lists = client.list_database_names()
db = client["student"]
# status = db["student"].delete_many({})
#改
# user = {"username":"王"}
# newuser = {"$set":{"username":"王瑞敏"}}
# status = db["student"].update_one(user,newuser)
#查
user ={"sex":"女"}
status = db["student"].find_one(user)
print(status)











