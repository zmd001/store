class AgeException(BaseException):
    def __init__(self,age):
        self.arg=age
class Person:
    __age = None
    def setAge(self,age):
        if age <= 0:
            raise AgeException("")
        else:
            self.__age=age
    def getAge(self):
        return self.__age
p = Person()
try:
    p.setAge(-1)
except AgeException:
    print("年龄输入错误")
