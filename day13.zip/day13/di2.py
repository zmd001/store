class Bank:
    money = None
    def draw(self,money1):
        if self.money < money1 :
            raise KeyError("金额不足异常")
        else:
            print(self.money-money1)
b = Bank()
b.money= 3000
try:
    b.draw(int(input()))
except KeyError:
    print("金额不足异常")