def getNum(li,index):
    return li[index]
a = []
index = 1
try:
    print(1/0)
    print(a[2],index)
    raise KeyError("")
except IndexError:
    print("出现了角标异常")
except ZeroDivisionError:
    print("被除数不能为0")
except Exception:
    print("其他异常")