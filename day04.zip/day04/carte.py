shop = [
    ["Iphone 12A",12000],
    ["Mac laptop",15000],
    ["lenovo laotop",4000],
    ["洗衣粉",25.6],
    ["辣条",1],
    ["电视",3600]
]
#1.展示商品
def showshop():
    for index,value in enumerate(shop):
        print(index,value)
#2.初始化金额
salary = 0
while True:
    salary = input("请输入您的账户余额：")
    if salary.isdigit():
        salary = int(salary)
        break
    else:
        print("对不起，您输入有误！请重新输入！")
#3.开始购物
mycart = []
print("----------------------欢迎来到Jason商店-------------------")
while True:
    showshop()
    chose = input("请输入您要的编号：")
    if chose.isdigit():
        chose = int(chose)
        if chose > len(shop)-1:
            print("对不起，没有这个商品！")
        else:
            if salary < shop[chose][1] :
                print("金额不足！")
            else:
                mycart.append(shop[chose])
                salary = salary - shop[chose][1]
                print("添加成功！余额还剩：",round(salary,1))
    elif chose == 'Q' or chose == 'q':
        print("拜拜！，欢迎下次再来！")
        break
    else:
        print("对不起，输入非法！请从新输入！")
print("您的购物清单如下:")
for item in mycart:
    print(item)
print("您的余额还剩：",round(salary,1))
